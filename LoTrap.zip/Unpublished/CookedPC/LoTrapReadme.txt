* Necessary steps:

* Add ModPackages=LoTrap to UTEditor.ini under the [ModPackages] section
* Run with -useunpublished
* use the WeaponReplacement mutator to swap your weapon for the LoTrap gun, or place a PickupFactory in the level and select the LoTrap gun
* I have included a map, DM-LoTrapTest for quick testing of this gun.  There is a single pickup factory placed with the gun directly in front of the spawn point.

This weapon works best in wide open spaces, and especially in areas that have death traps in them!

Some of the most fun we had with this gun was