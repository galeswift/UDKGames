LoTrap Gun for UT3 - Make Something Unreal
Created by Keith Miron (Programming), and Alan Lee (Art)
Email: kmiron@gmail.com

Purpose:
--------
* This gun was created to mimic that which was made for the game Portal from Valve.
* In addition to recreate the 'fun' aspects of the portal gun, I desired to actually see it used in a multiplayer environment, in malicious, completely irresponsible ways


Installation steps:
-------------------
* Extract the contents of the zip file to your My Documents\My Games\Unreal Tournament 3\UTGame\ folder.
* Inside UTeditor.ini, you should see an entry for ModPackages=LoTrap under the [ModPackages] section
* Run UT3.exe with -useunpublished
* use the WeaponReplacement mutator to swap your weapon for the LoTrap gun, or place a PickupFactory in the level and select the LoTrap gun
* I have included a map, DM-LoTrapTest for quick testing of this gun.  There is a single pickup factory placed with the gun directly in front of the spawn point.

Notes:
------
* This weapon works best in wide open spaces, and especially in areas that have death traps in them! 
* Some of the most fun we had with this gun was in the very simple test level that is provided, shooting portals in the ceiling, and trying to shoot the other portal under the feet of the opponent!

Features:
---------
* Portals will teleport projectiles, and players alike
* Speedy thing goes in, speedy thing comes out!
* Can place portals on walls, floors, ceilings, whatever!

Known Issues:
-------------
* There are some surfaces that the portal can not be placed on.
* Even if you have two portals placed, you may not necessarily be able to enter them, as there must be enough room for you to stand at the destination