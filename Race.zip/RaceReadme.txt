Race for UT3 - Make Something Unreal - Best Gametype Submission
Created by Matthew Fawcett
Email: blakvege@gmail.com

Purpose:
--------
* The goal for this gametype was to create a mode that feels like a fast rootrace, yet with weaponry and crazy jumps!
* We've implemented a checkpoint and stamina system to make it really feel like you are fighting against time to get in first place.

Installation steps:
-------------------
* Extract the contents of the zip file to your My Documents\My Games\Unreal Tournament 3\UTGame\ folder.
* Run UT3.exe with -useunpublished
* Select the Race gametype (It should be listed above deathmatch)
* Choose the RACE-LevelBlockIn map
* Invite some friends!
* Get in first place!

Notes:
------
* In order to use the sprint functionality, press the Left Shift key.  Sprint stamina will gradually replenish over time
* There is a built in handicap system which gives players that are falling behind more stamina, in order to be able to sprint longer!

Features:
---------
* Checkpoint system which determines who is currently leading the race
* Ability to specify lap length through the UTRace.ini file
* Respawning will place you where you were last killed